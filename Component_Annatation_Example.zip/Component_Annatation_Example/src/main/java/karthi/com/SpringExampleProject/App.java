package karthi.com.SpringExampleProject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Interface.Interface;

public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
       Interface i=(Interface) ac.getBean("model1");
       i.modelMethod();
    }
}
