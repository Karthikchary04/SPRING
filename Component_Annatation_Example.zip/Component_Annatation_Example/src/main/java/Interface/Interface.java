package Interface;

public interface Interface 
{
    void modelMethod();
}
