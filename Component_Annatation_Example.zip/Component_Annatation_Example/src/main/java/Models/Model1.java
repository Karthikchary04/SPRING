package Models;

import org.springframework.stereotype.Component;

import Interface.Interface;

@Component
public class Model1 implements Interface
{
    public void modelMethod()
    {
    	System.out.println("This is Model one method");
    }
}
