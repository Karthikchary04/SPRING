package karthi.com.Object_Injection_Example;

public class Student_Model_Object 
{
   @Override
	public String toString() {
		return "Student_MOdel_Object [st1="+ st1.getName() + ", st2=" + st2.getName() + ", st3=" + st3.getMarks() + "]";
	}
private Student_Model st1;
   private Student_Model st2;
   private Student_Model st3;
public Student_Model getSt1() {
	return st1;
}
public void setSt1(Student_Model st1) {
	this.st1 = st1;
}
public Student_Model getSt2() {
	return st2;
}
public void setSt2(Student_Model st2) {
	this.st2 = st2;
}
public Student_Model getSt3() {
	return st3;
}
public void setSt3(Student_Model st3) {
	this.st3 = st3;
}
   
}
