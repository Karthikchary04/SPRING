package karthi.com.AutoWrirting_Example;

public class Student_Model 
{
   private String name;
   private int marks;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
   
}
