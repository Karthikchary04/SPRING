package karthi.com.AutoWrirting_Example;

public class Student_Model_Object
{
   private Student_Model s1;
   private Student_Model s2;
   private Student_Model s3;
public Student_Model getS1() {
	return s1;
}
public void setS1(Student_Model s1) {
	this.s1 = s1;
}
public Student_Model getS2() {
	return s2;
}
public void setS2(Student_Model s2) {
	this.s2 = s2;
}
public Student_Model getS3() {
	return s3;
}
public void setS3(Student_Model s3) {
	this.s3 = s3;
}
@Override
public String toString() {
	return "Student_Model_Object [s1=" + s1.getName() + ", s2=" + s2.getName() + ", s3=" + s3.getName() + "]";
}
    
}
