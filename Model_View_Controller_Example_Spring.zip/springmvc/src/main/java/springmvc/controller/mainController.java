package springmvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Example_Model;

@Controller
public class mainController 
{
	@RequestMapping("/register")
    public ModelAndView req(HttpServletRequest req,HttpServletResponse res)
    {
		ModelAndView mav=new ModelAndView();
		Example_Model em=new Example_Model();
		em.setName(req.getParameter("name"));
		em.setEmail(req.getParameter("email"));
		em.setGender(req.getParameter("gender"));
		em.setCity(req.getParameter("city"));
		mav.addObject("values",em);
		mav.setViewName("index.jsp");
		return mav;
    	
    }
}
