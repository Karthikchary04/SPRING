package karthi.com.Contrustor_Injection_Example;

public class Student_Model
{
    private String name;
    private int marks;
	public Student_Model(String name, int marks) 
	{
		super();
		this.name = name;
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Student_Model [name=" + name + ", marks=" + marks + "]";
	}
    
}
