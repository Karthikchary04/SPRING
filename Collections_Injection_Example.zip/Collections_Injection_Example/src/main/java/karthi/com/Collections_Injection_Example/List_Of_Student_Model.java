package karthi.com.Collections_Injection_Example;

import java.util.List;

public class List_Of_Student_Model 
{
    private List<Student_Model> list;

	public List<Student_Model> getList() {
		return list;
	}

	public void setList(List<Student_Model> list) {
		this.list = list;
	}
    
	public void listOfStudents()
	{
		for(Student_Model s:list)
		{
			System.out.println(s.getName());
		}
	}
}
